let pdfDoc = null;
let currentPageOrder = [];
let currentPDF = null;

// Initialize sortable list
const initSortable = () => {
    new Sortable(document.getElementById('pageThumbnails'), {
        animation: 150,
        onUpdate: () => updatePageOrder()
    });
};

// Update page order when dragged
const updatePageOrder = () => {
    currentPageOrder = Array.from(document.querySelectorAll('.page-thumb'))
        .map(thumb => parseInt(thumb.dataset.pageIndex));
    document.getElementById('saveBtn').disabled = false;
};

// Handle PDF upload
document.getElementById('pdfInput').addEventListener('change', async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    document.getElementById('closeBtn').disabled = false;
    const reader = new FileReader();
    reader.onload = async () => {
        const pdfData = new Uint8Array(reader.result);
        currentPDF = pdfData;
        await loadPDF(pdfData);
    };
    reader.readAsArrayBuffer(file);
});

// Load PDF and show thumbnails
const loadPDF = async (pdfData) => {
    const loadingTask = pdfjsLib.getDocument({ data: pdfData });
    pdfDoc = await loadingTask.promise;

    currentPageOrder = Array.from({ length: pdfDoc.numPages }, (_, i) => i);
    document.getElementById('pageThumbnails').innerHTML = '';

    // Create thumbnails
    for (let i = 0; i < pdfDoc.numPages; i++) {
        const page = await pdfDoc.getPage(i + 1);
        const viewport = page.getViewport({ scale: 0.5 });

        const canvas = document.createElement('canvas');
        const context = canvas.getContext('2d');
        canvas.height = viewport.height;
        canvas.width = viewport.width;

        await page.render({ canvasContext: context, viewport }).promise;

        const thumbDiv = document.createElement('div');
        thumbDiv.className = 'page-thumb';
        thumbDiv.dataset.pageIndex = i;
        thumbDiv.innerHTML = `
            <span style="margin-right:10px">Page ${i + 1}</span>
            <canvas width="${viewport.width}" height="${viewport.height}"></canvas>
            <button onclick="deletePage(${i})" style="margin-left:auto">Delete</button>
        `;
        thumbDiv.querySelector('canvas').getContext('2d').drawImage(canvas, 0, 0);

        document.getElementById('pageThumbnails').appendChild(thumbDiv);
    }

    initSortable();
    document.getElementById('saveBtn').disabled = false;
};

// Delete page
window.deletePage = (index) => {
    currentPageOrder = currentPageOrder.filter(i => i !== index);
    document.querySelector(`[data-page-index="${index}"]`).remove();
    document.getElementById('saveBtn').disabled = false;
};

// Save modified PDF
window.saveModifiedPDF = async () => {
    if (!pdfDoc) return;

    const newPdfDoc = await PDFLib.PDFDocument.create();
    const originalPdf = await PDFLib.PDFDocument.load(currentPDF);

    // Copy pages in new order
    for (const pageIndex of currentPageOrder) {
        const [copiedPage] = await newPdfDoc.copyPages(originalPdf, [pageIndex]);
        newPdfDoc.addPage(copiedPage);
    }

    // Create download link
    const pdfBytes = await newPdfDoc.save();
    const blob = new Blob([pdfBytes], { type: 'application/pdf' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = 'modified.pdf';
    link.click();
};

// Close editor and reset everything
window.closeEditor = () => {
    document.getElementById('pdfInput').value = '';
    document.getElementById('pageThumbnails').innerHTML = '';
    document.getElementById('saveBtn').disabled = true;
    document.getElementById('closeBtn').disabled = true;
    pdfDoc = null;
    currentPDF = null;
    currentPageOrder = [];
};